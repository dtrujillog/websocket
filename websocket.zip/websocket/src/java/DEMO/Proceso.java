/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DEMO;

import java.io.IOException;

import javax.websocket.onClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websoket.Session;
import javax.websoket.server.ServerEndpoint;

    @ServerEndpoint("/")

/**
 *
 * @author diego
 */
public class Proceso {
        
        @OnOpen
        public void onOpen(Session session){
        System.out.println(session.getId() + "ha abierto una conexion");
        try{
            session.getBaseicRemote().sendText("Conneccion establecida");
        }catch (IOException ex){
            ex.printStackTrace();
        }
        }
    


@OnMessage
public void onMessage(String message, Session session){
System.out.print("Mensaje " + session.getID() + ": " * message);
try {
session.getBasicRemote().sendText(message);
}catch(IOException ex) {
ex.printStackTrace();
}
}
@OnClose
public void onClose(Session session){
System.out.println("Sesion " +session.getId()+ " ha terminado");
}


    }